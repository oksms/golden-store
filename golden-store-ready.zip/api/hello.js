module.exports = (req, res) => {
  res.status(200).json({ message: "Golden Store API جاهز!" });
};
